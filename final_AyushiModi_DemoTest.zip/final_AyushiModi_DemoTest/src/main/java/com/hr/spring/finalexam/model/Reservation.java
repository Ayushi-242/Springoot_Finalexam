package com.hr.spring.finalexam.model;
import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Reservation {

    @Id
    private String id; // MongoDB automatically assigns this as the unique identifier
    private String firstName;
    private String lastName;
    private int noOfPassengers;
    private String classOfTravel;
    private String phoneNo;
    private String dateOfDeparture;
    private int customerId;
    private List<Payment> payments;

    // Getters and setters for all fields
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFirstName() { return firstName; }
    public void setFirstName(String firstName) { this.firstName = firstName; }

    public String getLastName() { return lastName; }
    public void setLastName(String lastName) { this.lastName = lastName; }

    public int getNoOfPassengers() { return noOfPassengers; }
    public void setNoOfPassengers(int noOfPassengers) { this.noOfPassengers = noOfPassengers; }

    public String getClassOfTravel() { return classOfTravel; }
    public void setClassOfTravel(String classOfTravel) { this.classOfTravel = classOfTravel; }

    public String getPhoneNo() { return phoneNo; }
    public void setPhoneNo(String phoneNo) { this.phoneNo = phoneNo; }

    public String getDateOfDeparture() { return dateOfDeparture; }
    public void setDateOfDeparture(String dateOfDeparture) { this.dateOfDeparture = dateOfDeparture; }

    public int getCustomerId() { return customerId; }
    public void setCustomerId(int customerId) { this.customerId = customerId; }

    public List<Payment> getPayments() { return payments; }
    public void setPayments(List<Payment> payments) { this.payments = payments; }
}
//UPDATED