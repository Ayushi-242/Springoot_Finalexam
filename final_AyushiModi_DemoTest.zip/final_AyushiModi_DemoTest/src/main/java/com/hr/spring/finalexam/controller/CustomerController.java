package com.hr.spring.finalexam.controller;

import com.hr.spring.finalexam.model.Customer;
import com.hr.spring.finalexam.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/customers")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    // POST request to create a customer
    @PostMapping
    public Mono<ResponseEntity<Customer>> createCustomer(@RequestBody Customer customer) {
        return customerService.createCustomer(customer)
                .map(savedCustomer -> ResponseEntity.status(HttpStatus.CREATED).body(savedCustomer));
    }

    // GET request to fetch a customer by id
    @GetMapping("/{id}")
    public Mono<Customer> getCustomerById(@PathVariable("id") String id) {  // Using String as id
        return customerService.getCustomerById(id);
    }

    // GET request to fetch all customers
    @GetMapping
    public Flux<Customer> getAllCustomers() {
        return customerService.getAllCustomers();
    }
}
//ADDED	