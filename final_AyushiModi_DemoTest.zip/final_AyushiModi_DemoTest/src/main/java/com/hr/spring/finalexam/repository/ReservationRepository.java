package com.hr.spring.finalexam.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import com.hr.spring.finalexam.model.Reservation;

public interface ReservationRepository extends ReactiveMongoRepository<Reservation, String> {
    // Uses Reservation model and String as the ID type
}
