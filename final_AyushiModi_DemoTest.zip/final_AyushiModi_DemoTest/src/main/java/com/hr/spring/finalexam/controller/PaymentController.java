package com.hr.spring.finalexam.controller;

import com.hr.spring.finalexam.model.Payment;
import com.hr.spring.finalexam.service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    // Create a new payment
    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Mono<Payment> createPayment(@RequestBody Payment payment) {
        return paymentService.createPayment(payment);
    }

    // Get all payments
    @GetMapping
    public Mono<Flux<Payment>> getAllPayments() {
        return paymentService.getAllPayments();
    }

    // Get payment by id
    @GetMapping("/{id}")
    public Mono<Payment> getPaymentById(@PathVariable("id") int id) {
        return paymentService.getPaymentById(id);
    }
}
//added