package com.hr.spring.finalexam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hr.spring.finalexam.model.Reservation;
import com.hr.spring.finalexam.repository.ReservationRepository;
import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class ReservationService {

    @Autowired
    private ReservationRepository reservationRepository;

    // Create a new reservation
    public Mono<Reservation> createReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    // Retrieve all reservations
    public Flux<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }
}
