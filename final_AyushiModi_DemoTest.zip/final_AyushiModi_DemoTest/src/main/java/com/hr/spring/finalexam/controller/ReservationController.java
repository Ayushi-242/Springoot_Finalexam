	package com.hr.spring.finalexam.controller;
	
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RestController;
	
	import com.hr.spring.finalexam.model.Reservation;
	
	import reactor.core.publisher.Flux;
	import reactor.core.publisher.Mono;
	
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.web.bind.annotation.*;
	
	import com.hr.spring.finalexam.service.ReservationService;
	
	//This handles HTTP requests related to reservations
	@RestController
	@RequestMapping("/api")
	public class ReservationController {
	
	    @Autowired
	    private ReservationService reservationService;
	
	    // Create a new reservation
	    @PostMapping("/reservation")
	    public Mono<Reservation> createReservation(@RequestBody Reservation reservation) {
	        return reservationService.createReservation(reservation);
	    }
	
	    // Get all reservations
	    @GetMapping("/reservation")
	    public Flux<Reservation> getAllReservations() {
	        return reservationService.getAllReservations();
	    }
	}
	
