package com.hr.spring.finalexam.controller;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hr.spring.finalexam.model.Reservation;

//It serves as a controller for any web pages (e.g., index.html, reservations-list.html).

@Controller
public class WebControoler {

    @Autowired
    private ReservationController restController; // RestController for handling API calls

    // Home Page - Render the Reservation Form
    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("reservation", new Reservation()); // Add a blank Reservation object
        return "index"; // Thymeleaf template for reservation form
    }

    // Handle Reservation Form Submission
    @PostMapping("/reservation/add")
    public String submitReservationForm(@ModelAttribute Reservation reservation) {
        try {
            // Save reservation to a JSON file for demonstration purposes
            File file = new File("reservations.json");
            ObjectMapper objectMapper = new ObjectMapper();

            if (file.exists()) {
                // Read existing data and append the new reservation
                List<Reservation> reservations = new ArrayList<>(
                        Arrays.asList(objectMapper.readValue(file, Reservation[].class)));
                reservations.add(reservation);
                objectMapper.writeValue(file, reservations);
            } else {
                // Write the first reservation to a new file
                objectMapper.writeValue(file, Collections.singletonList(reservation));
            }

            // Post the reservation to the API
            restController.createReservation(reservation).subscribe();
        } catch (IOException e) {
            e.printStackTrace();
            return "error"; // Return error page in case of exceptions
        }

        return "redirect:/reservations"; // Redirect to the reservations list page
    }

    // Display All Reservations
    @GetMapping("/reservations")
    public String listReservations(Model model) {
    	List<Reservation> reservations = new ArrayList<>();

        // Try to fetch reservations from the API (RestController)
        reservations = restController.getAllReservations()
                .collectList() // Collect the reactive stream into a list
                .block(); // Block to wait for the data (not recommended for production)

        // reading from the JSON file
        if (reservations == null || reservations.isEmpty()) {
            try {
                File file = new File("reservations.json");
                if (file.exists()) {
                    ObjectMapper objectMapper = new ObjectMapper();
                    reservations = new ArrayList<>(Arrays.asList(objectMapper.readValue(file, Reservation[].class)));
                }
            } catch (IOException e) {
                e.printStackTrace();
                return "error"; // Return error page in case of exceptions
            }
        }

        model.addAttribute("reservations", reservations); // Add the list of reservations to the model
        return "reservations-list"; 
    }// Thymeleaf template for displaying reservations }
}
