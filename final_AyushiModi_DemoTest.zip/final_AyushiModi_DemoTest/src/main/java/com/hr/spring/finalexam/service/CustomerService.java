package com.hr.spring.finalexam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hr.spring.finalexam.model.Customer;
import com.hr.spring.finalexam.repository.CustomerRepository;

import reactor.core.publisher.Flux;
import reactor.core.publisher.Mono;

@Service
public class CustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    // Corrected to return Mono<Customer>
    public Mono<Customer> createCustomer(Customer customer) {
        return customerRepository.save(customer); // Saving customer
    }

    // Corrected to return Mono<Customer> (assuming you're using String as id in MongoDB)
    public Mono<Customer> getCustomerById(String id) {
        return customerRepository.findById(id); // Find by String id
    }

    // Corrected to return Flux<Customer> instead of Mono<Flux<Customer>>
    public Flux<Customer> getAllCustomers() {
        return customerRepository.findAll(); // Just return Flux directly
    }
}
//ADDED