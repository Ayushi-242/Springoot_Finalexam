package com.hr.spring.finalexam.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

@Document
public class Payment {

    // Remove or comment out the manual id
    // @Id
    // private int id;

    private double amount;
    private Date paymentDate;
    private PaymentMethod paymentMethod; // Enum for different payment methods

    // Enum for payment methods
    public enum PaymentMethod {
        CREDIT_CARD,
        PAYPAL,
        CASH,
        DEBIT_CARD // Add this line
    }

    // Getters and Setters
    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public Date getPaymentDate() {
        return paymentDate;
    }

    public void setPaymentDate(Date paymentDate) {
        this.paymentDate = paymentDate;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
}
