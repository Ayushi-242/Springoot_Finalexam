package com.hr.spring.finalexam.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import com.hr.spring.finalexam.model.Customer;

public interface CustomerRepository extends ReactiveMongoRepository<Customer, String> { // Change Integer to String for id
}
//NEW ADDED