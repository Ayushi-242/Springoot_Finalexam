package com.hr.spring.finalexam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

//Entry Point
@SpringBootApplication
public class AyushiModi_FinalExam_Application {

	public static void main(String[] args) {
		SpringApplication.run(AyushiModi_FinalExam_Application.class, args);
	}

}
