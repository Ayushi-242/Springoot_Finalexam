package com.hr.spring.finalexam.repository;

import org.springframework.data.mongodb.repository.ReactiveMongoRepository;
import com.hr.spring.finalexam.model.Payment;

public interface PaymentRepository extends ReactiveMongoRepository<Payment, Integer> {
}
