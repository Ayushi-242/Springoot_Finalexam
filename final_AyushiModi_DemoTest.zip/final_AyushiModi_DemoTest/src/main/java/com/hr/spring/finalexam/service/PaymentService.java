package com.hr.spring.finalexam.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.hr.spring.finalexam.model.Payment;
import com.hr.spring.finalexam.repository.PaymentRepository;

import reactor.core.publisher.Mono;
import reactor.core.publisher.Flux;

@Service
public class PaymentService {

    @Autowired
    private PaymentRepository paymentRepository;

    // Create a new payment
    public Mono<Payment> createPayment(Payment payment) {
        return paymentRepository.save(payment);
    }

    // Get payment by id
    public Mono<Payment> getPaymentById(int id) {
        return paymentRepository.findById(id);
    }

    // Get all payments
    public Mono<Flux<Payment>> getAllPayments() {
        return Mono.just(paymentRepository.findAll());
    }
}
//added