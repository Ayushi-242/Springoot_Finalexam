package com.hr.spring.finalexam;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AyushiModi_FinalExam_ApplicationTests {

	@Test
	void contextLoads() {
	}

}
